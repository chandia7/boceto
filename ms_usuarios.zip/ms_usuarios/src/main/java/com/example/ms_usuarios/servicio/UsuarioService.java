package com.example.ms_usuarios.servicio;

import java.util.List;
import org.springframework.stereotype.Service;

import com.example.ms_usuarios.exception.UsuarioException;
import com.example.ms_usuarios.modelo.Usuario;
import com.example.ms_usuarios.repository.UsuarioRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class UsuarioService {

    private UsuarioRepository usuarioRepository;



	public List<Usuario> listar(){
		return usuarioRepository.findAll();
	}

	public Usuario guardar(Usuario usuario){
		return usuarioRepository.save(usuario);
	}

	public Usuario buscarId(Long id){
		return usuarioRepository.findById(id)
                .orElseThrow(()->new UsuarioException(id));
	}
}

