package com.example.ms_usuarios.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.ms_usuarios.modelo.Usuario;

import java.util.List;


@Repository
public interface UsuarioRepository extends
JpaRepository<Usuario,Long> {

    List<Usuario> findById(long id);
    @Query("Select p from usuario p where p.nombre=:nombre")
    List<Usuario> findByUsuarios(@Param("nombre") String nombre);
    List<Usuario> findByApellido(@Param("apellido")String apellido);
    
    Usuario findByCorreo(String correo);
}
