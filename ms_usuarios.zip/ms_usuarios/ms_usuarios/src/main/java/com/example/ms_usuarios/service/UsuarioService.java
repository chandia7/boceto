package com.example.ms_usuarios.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.ms_usuarios.modelo.Usuario;
import com.example.ms_usuarios.repository.UsuarioRepository;



@Service
public class UsuarioService {

	@Autowired
    private UsuarioRepository repo;

	// Crear o guardar un nuevo usuario
	public Usuario guardarUsuario(Usuario usuario){
		// Le asignamos la fecha actual automáticamente antes de guardar
		if (usuario.getFechaRegistro()==null){
			usuario.setFechaRegistro(LocalDate.now());
		}
		return repo.save(usuario);
	}

	public Usuario buscarPorId(Long id){
		// .orElse(null) hace que si no lo encuentra, devuelva un nulo
		return repo.findById(id).orElse(null);
	}

	// Buscar por el ID de seguridad (idAuth)
    public Usuario buscarPorIdAuth(Long idAuth) {
        return repo.findByIdAuth(idAuth).orElse(null);
    }

	public List<Usuario> buscarPorApellido(String texto){
		return repo.findByApellidoContaining(texto);
	}

	//Eliminar un usuario
	public void eliminarUsuario(Long id){
		if(repo.existsById(id)) {
			repo.deleteById(id);
		}
	}

	// Validar si el correo ya existe
	public boolean existeCorreo(String email) {
		return repo.existsByEmail(email);
	}


	
}

