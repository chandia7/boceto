package com.example.ms_seguimiento.controller;

import com.example.ms_seguimiento.model.Seguimiento;
import com.example.ms_seguimiento.service.SeguimientoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/seguimiento")
public class SeguimientoController {

    private final SeguimientoService seguimientoService;

    public SeguimientoController(SeguimientoService seguimientoService) {
        this.seguimientoService = seguimientoService;
    }

    @PostMapping
    public Seguimiento registrar(@RequestBody Seguimiento seguimiento) {
        return seguimientoService.registrarSeguimiento(seguimiento);
    }

    @GetMapping
    public List<Seguimiento> listar() {
        return seguimientoService.listarSeguimientos();
    }

    @GetMapping("/{id}")
    public Seguimiento obtener(@PathVariable Long id) {
        return seguimientoService.obtenerPorId(id);
    }

    @GetMapping("/pedido/{idPedido}")
    public List<Seguimiento> historial(@PathVariable Long idPedido) {
        return seguimientoService.obtenerHistorial(idPedido);
    }
}