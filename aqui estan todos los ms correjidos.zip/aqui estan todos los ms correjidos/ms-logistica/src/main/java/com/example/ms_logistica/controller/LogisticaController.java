package com.example.ms_logistica.controller;


import com.example.ms_logistica.model.Logistica;
import com.example.ms_logistica.service.LogisticaService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/logistica")
public class LogisticaController {

    private final LogisticaService logisticaService;

    public LogisticaController(LogisticaService logisticaService) {
        this.logisticaService = logisticaService;
    }

    @PostMapping
    public Logistica crear(@RequestBody Logistica logistica) {
        return logisticaService.crearProceso(logistica);
    }

    @PutMapping("/{idPedido}")
    public Logistica actualizarEstado(
            @PathVariable Long idPedido,
            @RequestParam String estado) {
        return logisticaService.actualizarEstado(idPedido, estado);
    }

    @GetMapping("/{idPedido}")
    public Logistica obtener(@PathVariable Long idPedido) {
        return logisticaService.obtenerPorPedido(idPedido);
    }

    @GetMapping
    public List<Logistica> listar() {
        return logisticaService.listarProcesos();
    }
}