package com.example.ms_logistica.service;

import com.example.ms_logistica.model.Logistica;
import com.example.ms_logistica.model.Logistica.EstadoLogistica;
import com.example.ms_logistica.repository.LogisticaRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class LogisticaService {

    private final LogisticaRepository logisticaRepository;

    public LogisticaService(LogisticaRepository logisticaRepository) {
        this.logisticaRepository = logisticaRepository;
    }

    // Crear proceso logístico
    public Logistica crearProceso(Logistica logistica) {

        logistica.setEstado(EstadoLogistica.DOCUMENTACION_EN_REVISION.name());
        logistica.setFechaActualizacion(LocalDateTime.now());

        return logisticaRepository.save(logistica);
    }

    // Actualizar estado
    public Logistica actualizarEstado(Long idPedido, String nuevoEstado) {

        Logistica logistica = logisticaRepository.findByIdPedido(idPedido)
                .orElseThrow(() -> new RuntimeException("Proceso logístico no encontrado"));

        logistica.setEstado(nuevoEstado);
        logistica.setFechaActualizacion(LocalDateTime.now());

        return logisticaRepository.save(logistica);
    }

    // Obtener por pedido
    public Logistica obtenerPorPedido(Long idPedido) {
        return logisticaRepository.findByIdPedido(idPedido)
                .orElseThrow(() -> new RuntimeException("Proceso no encontrado"));
    }

    // Listar todos
    public List<Logistica> listarProcesos() {
        return logisticaRepository.findAll();
    }
}
