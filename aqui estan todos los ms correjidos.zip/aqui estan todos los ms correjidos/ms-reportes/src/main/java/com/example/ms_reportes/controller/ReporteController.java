package com.example.ms_reportes.controller;

import com.example.ms_reportes.model.Reporte;
import com.example.ms_reportes.service.ReporteService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reportes")
public class ReporteController {

    private final ReporteService reporteService;

    public ReporteController(ReporteService reporteService) {
        this.reporteService = reporteService;
    }

    // 🔥 Generar reporte en tiempo real
    @PostMapping("/generar")
    public Reporte generarReporte() {
        return reporteService.generarReporte();
    }

    // 📊 Historial
    @GetMapping
    public List<Reporte> listar() {
        return reporteService.listarReportes();
    }

    // 🔍 Detalle
    @GetMapping("/{id}")
    public Reporte obtener(@PathVariable Long id) {
        return reporteService.obtenerReporte(id);
    }
}