package com.example.ms_reportes.DTOs;

import lombok.Data;

import java.time.LocalDate;

@Data
public class PedidoDTO {
    private Long id;
    private String estado;
    private LocalDate fecha;
}