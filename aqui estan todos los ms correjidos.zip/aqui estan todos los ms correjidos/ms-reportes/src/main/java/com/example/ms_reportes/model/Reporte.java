package com.example.ms_reportes.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "reporte")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Reporte {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private BigDecimal totalVentas;

    @Column(nullable = false)
    private Integer totalPedidos;

    @Column(nullable = false)
    private Long pedidosCompletados;

    @Column(nullable = false)
    private LocalDateTime fechaGeneracion;
}
