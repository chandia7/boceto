package com.example.ms_pedidos.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ms_pedidos.model.Pedidos;

import java.util.List;

public interface PedidoRepository extends JpaRepository<Pedidos, Long> {

    List<Pedidos> findByIdUsuario(Long idUsuario);

    List<Pedidos> findByEstado(String estado);
}