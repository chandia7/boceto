package com.example.ms_pedidos.model;

public enum EstadoPedido {
    CREADO,
    RESERVADO,
    PAGADO,
    EN_PROCESO,
    COMPLETADO,
    CANCELADO
}
