package com.example.ms_pedidos.controller;

import com.example.ms_pedidos.model.Pedidos;
import com.example.ms_pedidos.service.PedidoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pedidos")
public class PedidoController {

    private final PedidoService pedidoService;

    public PedidoController(PedidoService pedidoService) {
        this.pedidoService = pedidoService;
    }

    @PostMapping
    public Pedidos crear(@RequestBody Pedidos pedido) {
        return pedidoService.crearPedido(pedido);
    }

    @GetMapping
    public List<Pedidos> listar() {
        return pedidoService.listarPedidos();
    }

    @GetMapping("/{id}")
    public Pedidos obtener(@PathVariable Long id) {
        return pedidoService.obtenerPorId(id);
    }

    @GetMapping("/usuario/{idUsuario}")
    public List<Pedidos> obtenerPorUsuario(@PathVariable Long idUsuario) {
        return pedidoService.obtenerPorUsuario(idUsuario);
    }

    @PutMapping("/cancelar/{id}")
    public Pedidos cancelar(@PathVariable Long id) {
        return pedidoService.cancelarPedido(id);
    }

    @PutMapping("/completar/{id}")
    public Pedidos completar(@PathVariable Long id) {
        return pedidoService.completarPedido(id);
    }
}