package com.example.ms_pedidos.service;

import com.example.ms_pedidos.model.EstadoPedido;
import com.example.ms_pedidos.model.Pedidos;
import com.example.ms_pedidos.repository.PedidoRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class PedidoService {

    private final PedidoRepository pedidoRepository;

    public PedidoService(PedidoRepository pedidoRepository) {
        this.pedidoRepository = pedidoRepository;
    }

    public Pedidos crearPedido(Pedidos pedido) {

        pedido.setEstado(EstadoPedido.CREADO.name());
        pedido.setFechaCreacion(LocalDateTime.now());

        return pedidoRepository.save(pedido);
    }

    public List<Pedidos> listarPedidos() {
        return pedidoRepository.findAll();
    }

    public Pedidos obtenerPorId(Long id) {
        return pedidoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));
    }

    public List<Pedidos> obtenerPorUsuario(Long idUsuario) {
        return pedidoRepository.findByIdUsuario(idUsuario);
    }

    public Pedidos cancelarPedido(Long id) {

        Pedidos pedido = obtenerPorId(id);
        pedido.setEstado(EstadoPedido.CANCELADO.name());

        return pedidoRepository.save(pedido);
    }

    public Pedidos completarPedido(Long id) {

        Pedidos pedido = obtenerPorId(id);
        pedido.setEstado(EstadoPedido.COMPLETADO.name());

        return pedidoRepository.save(pedido);
    }
}
