package com.example.ms_notificaciones.service;

import com.example.ms_notificaciones.model.Notificacion;
import com.example.ms_notificaciones.repository.NotificacionRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class NotificacionService {

    private final NotificacionRepository notificacionRepository;

    public NotificacionService(NotificacionRepository notificacionRepository) {
        this.notificacionRepository = notificacionRepository;
    }

    // Enviar notificación (simulación)
    public Notificacion enviarNotificacion(Notificacion notificacion) {

        try {
            // Aquí después integras JavaMailSender o API externa
            System.out.println("Enviando correo a: " + notificacion.getDestinatario());
            System.out.println("Asunto: " + notificacion.getAsunto());

            notificacion.setEstado("ENVIADO");

        } catch (Exception e) {
            notificacion.setEstado("ERROR");
        }

        notificacion.setFechaEnvio(LocalDateTime.now());

        return notificacionRepository.save(notificacion);
    }

    // Listar todas
    public List<Notificacion> listarNotificaciones() {
        return notificacionRepository.findAll();
    }

    // Buscar por destinatario
    public List<Notificacion> obtenerPorDestinatario(String email) {
        return notificacionRepository.findByDestinatario(email);
    }

    // Buscar por estado
    public List<Notificacion> obtenerPorEstado(String estado) {
        return notificacionRepository.findByEstado(estado);
    }
}