package com.example.ms_seguridad.dto;

import lombok.Data;

@Data
public class UsuarioDto {
    private String nombre;
    private String apellido;
    private String telefono;
    private String email;
    private Integer idAuth;


    
}
