package com.example.ms_seguridad.service;

import com.example.ms_seguridad.dto.RegistroRequestDto;
import com.example.ms_seguridad.dto.UsuarioDto;
import com.example.ms_seguridad.entity.UsuarioAuth;
import com.example.ms_seguridad.feign.UsuarioFeignClient;
import com.example.ms_seguridad.repository.UsuarioAuthRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UsuarioAuthService { // <-- ¡ESTE ERA EL ERROR! (el nombre)

    @Autowired
    private UsuarioAuthRepository repository;

    @Autowired
    private UsuarioFeignClient feignClient;

    @Transactional 
    public String registrarUsuario(RegistroRequestDto request) {
        
        // 1. Guardar en ms-seguridad
        UsuarioAuth auth = new UsuarioAuth();
        auth.setEmail(request.getEmail());
        auth.setPassword(request.getPassword()); 
        auth.setRol(request.getRol());
        
        UsuarioAuth authGuardado = repository.save(auth);
        
        // 2. Preparar el DTO para ms-usuarios
        UsuarioDto usuarioDto = new UsuarioDto();
        usuarioDto.setNombre(request.getNombre());
        usuarioDto.setApellido(request.getApellido());
        usuarioDto.setTelefono(request.getTelefono());
        usuarioDto.setEmail(request.getEmail());
        usuarioDto.setIdAuth(authGuardado.getId().intValue()); 
        
        // 3. ¡La llamada mágica! (Ahora sí funcionará)
        feignClient.crearUsuario(usuarioDto);
        
        return "Usuario y credenciales creados exitosamente";
    }
}
