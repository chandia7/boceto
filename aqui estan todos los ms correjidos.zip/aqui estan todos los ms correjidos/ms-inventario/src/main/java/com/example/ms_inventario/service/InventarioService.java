package com.example.ms_inventario.service;

import com.example.ms_inventario.model.Inventario;
import com.example.ms_inventario.model.Inventario.EstadoInventario;
import com.example.ms_inventario.repository.InventarioRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InventarioService {

    private final InventarioRepository inventarioRepository;

    public InventarioService(InventarioRepository inventarioRepository) {
        this.inventarioRepository = inventarioRepository;
    }

    // Crear stock
    public Inventario crearInventario(Inventario inventario) {

        if (inventarioRepository.existsByIdPropiedad(inventario.getIdPropiedad())) {
            throw new RuntimeException("La propiedad ya existe en inventario");
        }

        inventario.setEstado(EstadoInventario.DISPONIBLE.name());

        return inventarioRepository.save(inventario);
    }

    // Obtener todos
    public List<Inventario> listarInventario() {
        return inventarioRepository.findAll();
    }

    // Buscar por propiedad
    public Inventario obtenerPorPropiedad(Long idPropiedad) {
        return inventarioRepository.findByIdPropiedad(idPropiedad)
                .orElseThrow(() -> new RuntimeException("Inventario no encontrado"));
    }

    // Reservar
    public Inventario reservar(Long idPropiedad) {

        Inventario inventario = obtenerPorPropiedad(idPropiedad);

        if (!inventario.getEstado().equals(EstadoInventario.DISPONIBLE.name())) {
            throw new RuntimeException("No disponible");
        }

        inventario.setEstado(EstadoInventario.RESERVADO.name());

        return inventarioRepository.save(inventario);
    }

    // Confirmar venta
    public Inventario vender(Long idPropiedad) {

        Inventario inventario = obtenerPorPropiedad(idPropiedad);

        if (!inventario.getEstado().equals(EstadoInventario.RESERVADO.name())) {
            throw new RuntimeException("Debe estar reservado");
        }

        inventario.setEstado(EstadoInventario.VENDIDO.name());
        inventario.setStock(0);

        return inventarioRepository.save(inventario);
    }

    // Liberar reserva
    public Inventario liberar(Long idPropiedad) {

        Inventario inventario = obtenerPorPropiedad(idPropiedad);

        if (inventario.getEstado().equals(EstadoInventario.RESERVADO.name())) {
            inventario.setEstado(EstadoInventario.DISPONIBLE.name());
        }

        return inventarioRepository.save(inventario);
    }

    // Bloquear
    public Inventario bloquear(Long idPropiedad) {

        Inventario inventario = obtenerPorPropiedad(idPropiedad);

        inventario.setEstado(EstadoInventario.BLOQUEADO.name());

        return inventarioRepository.save(inventario);
    }
}
