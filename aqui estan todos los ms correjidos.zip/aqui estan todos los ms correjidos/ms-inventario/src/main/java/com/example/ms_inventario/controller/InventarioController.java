package com.example.ms_inventario.controller;

import com.example.ms_inventario.model.Inventario;
import com.example.ms_inventario.service.InventarioService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inventario")
public class InventarioController {

    private final InventarioService inventarioService;

    public InventarioController(InventarioService inventarioService) {
        this.inventarioService = inventarioService;
    }

    @PostMapping
    public Inventario crear(@RequestBody Inventario inventario) {
        return inventarioService.crearInventario(inventario);
    }

    @GetMapping
    public List<Inventario> listar() {
        return inventarioService.listarInventario();
    }

    @GetMapping("/{idPropiedad}")
    public Inventario obtener(@PathVariable Long idPropiedad) {
        return inventarioService.obtenerPorPropiedad(idPropiedad);
    }

    @PutMapping("/reservar/{idPropiedad}")
    public Inventario reservar(@PathVariable Long idPropiedad) {
        return inventarioService.reservar(idPropiedad);
    }

    @PutMapping("/vender/{idPropiedad}")
    public Inventario vender(@PathVariable Long idPropiedad) {
        return inventarioService.vender(idPropiedad);
    }

    @PutMapping("/liberar/{idPropiedad}")
    public Inventario liberar(@PathVariable Long idPropiedad) {
        return inventarioService.liberar(idPropiedad);
    }

    @PutMapping("/bloquear/{idPropiedad}")
    public Inventario bloquear(@PathVariable Long idPropiedad) {
        return inventarioService.bloquear(idPropiedad);
    }
}
