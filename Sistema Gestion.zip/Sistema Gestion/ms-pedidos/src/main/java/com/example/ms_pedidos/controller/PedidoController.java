package com.example.ms_pedidos.controller;

import com.example.ms_pedidos.model.Pedido;
import com.example.ms_pedidos.service.PedidoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pedidos")
public class PedidoController {

    private final PedidoService pedidoService;

    public PedidoController(PedidoService pedidoService) {
        this.pedidoService = pedidoService;
    }

    @PostMapping
    public Pedido crear(@RequestBody Pedido pedido) {
        return pedidoService.crearPedido(pedido);
    }

    @GetMapping
    public List<Pedido> listar() {
        return pedidoService.listarPedidos();
    }

    @GetMapping("/{id}")
    public Pedido obtener(@PathVariable Long id) {
        return pedidoService.obtenerPorId(id);
    }

    @GetMapping("/usuario/{idUsuario}")
    public List<Pedido> obtenerPorUsuario(@PathVariable Long idUsuario) {
        return pedidoService.obtenerPorUsuario(idUsuario);
    }

    @PutMapping("/cancelar/{id}")
    public Pedido cancelar(@PathVariable Long id) {
        return pedidoService.cancelarPedido(id);
    }

    @PutMapping("/completar/{id}")
    public Pedido completar(@PathVariable Long id) {
        return pedidoService.completarPedido(id);
    }
}