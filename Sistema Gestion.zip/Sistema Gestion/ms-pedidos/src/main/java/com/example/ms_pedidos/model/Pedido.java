package com.example.ms_pedidos.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "pedido")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Pedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "id_usuario", nullable = false)
    @NotNull(message = "El id del usuario es obligatorio")
    private Long idUsuario;

    @Column(name = "id_propiedad", nullable = false)
    @NotNull(message = "El id de la propiedad es obligatorio")
    private Long idPropiedad;

    private Long idPromocion;

    @Column(nullable = false)
    private BigDecimal montoFinal;

    @Column(nullable = false)
    private String estado;

    @Column(nullable = false)
    private LocalDateTime fechaCreacion;

}