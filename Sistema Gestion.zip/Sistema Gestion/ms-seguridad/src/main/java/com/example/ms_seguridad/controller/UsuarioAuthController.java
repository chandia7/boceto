package com.example.ms_seguridad.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.ms_seguridad.dto.RegistroRequestDto;
import com.example.ms_seguridad.service.UsuarioAuthService;

@RestController
@RequestMapping("/api/auth")
public class UsuarioAuthController {
    @Autowired
    private UsuarioAuthService service;

    @PostMapping("/registrar")
    public String registrar(@RequestBody RegistroRequestDto request) {
        return service.registrarUsuario(request);
    }

}
