package com.example.ms_promociones.service;

import com.example.ms_promociones.entity.Promocion;
import com.example.ms_promociones.repository.PromocionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PromocionService {

    @Autowired
    private PromocionRepository repository;

    public Promocion crearPromocion(Promocion promocion) {
        return repository.save(promocion);
    }

    public List<Promocion> obtenerTodas() {
        return repository.findAll();
    }
}