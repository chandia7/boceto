package com.example.ms_promociones.controller;

import com.example.ms_promociones.entity.Promocion;
import com.example.ms_promociones.service.PromocionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/promociones")
public class PromocionController {

    @Autowired
    private PromocionService service;

    @PostMapping
    public Promocion crear(@RequestBody Promocion promocion) {
        return service.crearPromocion(promocion);
    }

    @GetMapping
    public List<Promocion> listar() {
        return service.obtenerTodas();
    }
}
