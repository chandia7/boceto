package com.example.ms_reportes.DTOs;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class PedidoDTO {
    private Long id;
    private String estado;
    private LocalDateTime fechaCreacion;
}