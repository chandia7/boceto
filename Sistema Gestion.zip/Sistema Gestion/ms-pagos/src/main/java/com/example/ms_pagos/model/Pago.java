package com.example.ms_pagos.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "pago")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Pago {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "id_pedido", nullable = false)
    @NotNull(message = "El id del pedido es obligatorio")
    private Long idPedido;

    @Column(nullable = false)
    @NotNull(message = "El monto es obligatorio")
    private BigDecimal monto;


    @Pattern(regexp = "^\\s*(?i)(TRANSFERENCIA|TARJETA|EFECTIVO)\\s*$", message = "ERROR: DEBE ESCOGER ENTRE 'TRANSFERENCIA', 'TARJETA' o 'EFECTIVO'")
    @Column(nullable = false)
    private String metodoPago;

    @Column(nullable = false)
    private String estado;

    @Column(nullable = false)
    private LocalDateTime fechaPago;

    public enum EstadoPago {
        PENDIENTE,
        APROBADO,
        RECHAZADO
    }
}
