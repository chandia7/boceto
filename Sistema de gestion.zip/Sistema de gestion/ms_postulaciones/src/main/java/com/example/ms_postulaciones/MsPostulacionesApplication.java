package com.example.ms_postulaciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsPostulacionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsPostulacionesApplication.class, args);
	}

}
