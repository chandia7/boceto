package com.example.ms_propiedades;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsPropiedadesApplicationTests {

	@Test
	void contextLoads() {
	}

}
